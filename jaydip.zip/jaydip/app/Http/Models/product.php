<?php

namespace App\http\Models;

use Illuminate\Database\Eloquent\Model;

class product extends Model
{
    protected $table = 'product';
   protected $primarykey='id';


    public function setFirstUpdatedAtAttribute($value)
    {
        $this->attributes['updated_at'] = "0000-00-00";
    }
}
