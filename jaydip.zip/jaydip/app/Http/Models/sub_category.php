<?php

namespace App\http\Models;

use Illuminate\Database\Eloquent\Model;

class sub_category extends Model
{
   protected $table = 'sub_category';
}
