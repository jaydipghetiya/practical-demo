<?php

namespace App\Http\Controllers\User;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;
use Auth;

class UserController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $uid = Auth::id();
    	$user = User::whereNotIn('id',[$uid])->get();
    	return view('user.list', compact('user'));

    }

    public function updateUser(Request $request)
    {

    	$params = $request->all();
        $usserId  = array_get($params, 'user_id', 0);  
        $validatedData = $request->validate([
            'first_name' => 'required',
            'last_name'  => 'required',
            'email'      => 'required|email|max:255|unique:users,email,'.$usserId,
            'phone'      => 'required|unique:users,phone,'.$usserId,
        ]);

        $users  = new User(); 
        $user   = $users->updateUser($params);

        if($user) {
            return response()->json(['code' => 0, 'msg' => 'User Update Successfullay', 'data' => []]);
        }

        return response()->json(['code' => -1, 'msg' => 'Something went wrong!', 'data' => []]);
    }

    public function editUser($id)
    {
        $user = User::where('id', $id)->first();
    	return view('user.edit', compact('user'));
    }

    public function deleteUser(Request $request)
    {
        $params   = $request->all();
        $id       = array_get($params, 'id', 0);

        if(empty($id) || $id < 0) {
            return response()->json(['code' => -1, 'msg' => 'Required params missing!', 'data' => []]);
        }

        $location = new user();
        $result   = $location->deleteUser($params);

        if($result) {
            return response()->json(['code' => 0, 'msg' => 'user deleted successfully', 'data' => []]);
        }

        return response()->json(['code' => -1, 'msg' => 'Record not found!', 'data' => []]);
    }
}
