@extends('layouts.app')

@section('content')
<div class="container">
  <h2>Users</h2>
  <table class="table table-hover userTable">
    <thead>
      <tr>
        <th>First Name</th>
        <th>Last Name</th>
        <th>Email</th>
        <th>Phone</th>
         <th></th>
      </tr>
    </thead>
    <tbody>
      @foreach($user as $u)
      <tr class='table-tr-{{$u->id}}'>
        <td>{{$u->first_name}}</td>
        <td>{{$u->last_name}}</td>
        <td>{{$u->email}}</td>
        <td>{{$u->phone}}</td>
        <td></td>
        <td><a type="button" data-id="{{$u->id}}" class="btn btn-danger deleteUser">Delete</a> <a href="{{ url('/user/edit')}}/{{$u['id']}}" type="button" class="btn btn-info">Edit</a></td>
      </tr>
      @endforeach
    </tbody>
  </table>
</div>
<script type="text/javascript">
$("document").ready(function() {

  $('.deleteUser').click(function(){
      var $this = this;
      var id = $(this).attr('data-id');
      if(confirm('Are you sure want to delete this user ?')) {
          jQuery.ajax({
              url: "{{ url('/user/delete-user') }}",
              method: 'get',
              data: {
                  id: id,
              },
            success: function(data) {
                  if(data.code  == 0) {
                      $('.userTable  .table-tr-'+id).fadeOut( "slow", function() {
                        $('.userTable .table-tr-'+id).remove();
                      });
                  }
            }
            });
      }
    });
});
</script>
@endsection
