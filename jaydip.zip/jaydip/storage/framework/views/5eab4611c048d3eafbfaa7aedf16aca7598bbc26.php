<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="alert succesmsg">

    </div>
  <form class="form-horizontal updteuser">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">

    <div class="form-group">
      <label class="control-label col-sm-2" for="email">First Name:</label>
      <div class="col-sm-10">
        <input type="text" class="form-control required" value = "<?php echo e($user->first_name); ?>"  placeholder="" name="first_name">
        <span class="first_nameerror errormsg" style="color:red"></span>
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="email">Lase Name:</label>
      <div class="col-sm-10">
        <input type="text" class="form-control required" value = "<?php echo e($user->last_name); ?>"  placeholder="" name="last_name">
        <span class="last_nameerror errormsg" style="color:red"></span>
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="email">Email:</label>
      <div class="col-sm-10">
        <input type="email" class="form-control required" value = "<?php echo e($user->email); ?>"  placeholder="" name="email">
        <span class="emailerror errormsg" style="color:red"></span>
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="email">Phone:</label>
      <div class="col-sm-10">
        <input type="number" class="form-control required" value = "<?php echo e($user->phone); ?>"  placeholder="" name="phone">
        <span class="phoneerror errormsg" style="color:red"></span>
      </div>
    </div>
    <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
        <button type="submit" class="btn btn-default">Submit</button>
      </div>
    </div>
  </form>
</div>
<script type="text/javascript">
$("document").ready(function() {

  //update
   $('.updteuser').on('submit', function (e) {
          e.preventDefault();
          $('.errormsg').text('');  
          $.ajax({
            type: 'post',
            url: "<?php echo e(url('/user/update-user')); ?>",
            data: $('form').serialize(),
            error:function(data){
               console.log(data);
                $('.help-block').text('');
                var error = JSON.parse(data.responseText);
                $.each( error.errors, function( key, value ) {
                $('.'+key+'error').text(value[0]); //showing only the first error.
              });
            },
            success: function (data) {
                 $('.succesmsg').text('User register successfully');
                 $('.succesmsg').addClass('alert-success');
                 setTimeout(function(){ window.location.reload(); }, 3000);

            }
          });
    });
});
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>