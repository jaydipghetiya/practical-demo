<?php $__env->startSection('content'); ?>

<div class="container">
  <h2><?php echo e($action); ?> product</h2>
  <?php if(\Session::has('error')): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div><?php echo e($error); ?></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php if(\Session::has('success')): ?>
    <div class="alert alert-success">
        <ul>
            <li><?php echo \Session::get('success'); ?></li>
        </ul>
    </div>
<?php endif; ?>
  <form class="form-horizontal" method="post" action="<?php echo e(url('/product/storeproduct')); ?>" enctype="multipart/form-data">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        <input type="hidden" name="action" value="<?php echo $action;?>">
        <input type="hidden" name="proid" value="<?php echo $proId;?>">

    <div class="form-group">
      <label class="control-label col-sm-2" for="email">Product Name:</label>
      <div class="col-sm-10">
        <input type="text" class="form-control required" value = "<?php echo isset($product['product_name']) ? $product['product_name'] : "";?>"  placeholder="" name="productname">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Price:</label>
      <div class="col-sm-10">          
        <input type="text" class="form-control" id="pwd" placeholder="" value="<?php echo isset($product['price']) ? $product['price'] : "";?>" name="price">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Category:</label>
      <div class="col-sm-10">          
        <select name="category" onchange="getSubCateGory(this)" class="category form-control">
          <option value="">Select</option>
          <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->category_name); ?></option>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
    </div>
     <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Sub Category:</label>
      <div class="col-sm-10">          
        <select class="sub_category form-control" name="sub_category"><option>select</option>
        </select>
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Description:</label>
      <div class="col-sm-10">          
        <textarea class="form-control" rows="5" id="comment" value="" name="dec"><?php echo isset($product['description']) ? $product['description'] : "";?></textarea>
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Images:</label>
      <div class="col-sm-10">          
        <input type="file" id="files" name="files" />
      </div>
    </div>
    <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
        <button type="submit" class="btn btn-default">Submit</button>
      </div>
    </div>
  </form>
</div>
<script>
  $(document).ready(function() {
  if (window.File && window.FileList && window.FileReader) {
    $("#files").on("change", function(e) {
      var files = e.target.files,
        filesLength = files.length;
      for (var i = 0; i < filesLength; i++) {
        var f = files[i]
        var fileReader = new FileReader();
        fileReader.onload = (function(e) {
          var file = e.target;
          $("<span class=\"pip\">" +
            "<img class=\"imageThumb\" src=\"" + e.target.result + "\" title=\"" + file.name + "\"/>" +
            "<br/><span class=\"remove btn btn-default\">Remove image</span>" +
            "</span>").insertAfter("#files");
          $(".remove").click(function(){
            $(this).parent(".pip").remove();
            $('#files').val("");
          });
          
          // Old code here
          /*$("<img></img>", {
            class: "imageThumb",
            src: e.target.result,
            title: file.name + " | Click to remove"
          }).insertAfter("#files").click(function(){$(this).remove();});*/
          
        });
        fileReader.readAsDataURL(f);
      }
    });
  } else {
    alert("Your browser doesn't support to File API")
  }
});

function getSubCateGory($this)
{
    $.ajax({
           type: "GET",
           url: "<?php echo e(url('product/getSubCateGory')); ?>?cat_id="+$this.value,         
           data: "",
           success: function(data) {
            //var parsed_data = JSON.parse(data);
            var html ="";
            $.each(data, function(k, v) {
              html +="<option value='"+k+"'>"+v+"</option>";  
            });
            $('.sub_category').html(html);
           }
        });
};
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>