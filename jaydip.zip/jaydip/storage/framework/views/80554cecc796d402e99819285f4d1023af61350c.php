<?php $__env->startSection('content'); ?>
<div class="container">
  <h2>Product</h2> <a href="<?php echo e(url('product/addproduct')); ?>" style="float: left;" class="btn btn-default">Add Product</a>
  <table class="table table-hover">
    <thead>
      <tr>
        <th>Product</th>
        <th>Price</th>
        <th>Category</th>
        <th>Sub Category</th>
         <th></th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($pro['product_name']); ?></td>
        <td>$<?php echo e($pro['price']); ?></td>
        <td><?php echo isset($category[$pro['category_id']]) ? $category[$pro['category_id']] : "";?></td>
        <td><?php echo isset($sub_category[$pro['sub_category_id']]) ? $sub_category[$pro['sub_category_id']] : "";?></td>
        <td><img src="<?php echo e(url('/images/')); ?>/<?php echo e($pro['image']); ?>" height="50" widht="50" alt="Image"/></td>
        <td><a type="button" class="btn btn-danger">Delete</a> <a href="<?php echo e(url('/product/editproduct')); ?>?product_id=<?php echo e($pro['id']); ?>" type="button" class="btn btn-info">Edit</a></td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>