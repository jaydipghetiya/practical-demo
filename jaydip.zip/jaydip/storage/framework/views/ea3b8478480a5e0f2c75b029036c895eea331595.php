<?php $__env->startSection('content'); ?>
<div class="container">
  <h2>Users</h2>
  <table class="table table-hover userTable">
    <thead>
      <tr>
        <th>First Name</th>
        <th>Last Name</th>
        <th>Email</th>
        <th>Phone</th>
         <th></th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr class='table-tr-<?php echo e($u->id); ?>'>
        <td><?php echo e($u->first_name); ?></td>
        <td><?php echo e($u->last_name); ?></td>
        <td><?php echo e($u->email); ?></td>
        <td><?php echo e($u->phone); ?></td>
        <td></td>
        <td><a type="button" data-id="<?php echo e($u->id); ?>" class="btn btn-danger deleteUser">Delete</a> <a href="<?php echo e(url('/user/edit')); ?>/<?php echo e($u['id']); ?>" type="button" class="btn btn-info">Edit</a></td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>
<script type="text/javascript">
$("document").ready(function() {

  $('.deleteUser').click(function(){
      var $this = this;
      var id = $(this).attr('data-id');
      if(confirm('Are you sure want to delete this user ?')) {
          jQuery.ajax({
              url: "<?php echo e(url('/user/delete-user')); ?>",
              method: 'get',
              data: {
                  id: id,
              },
            success: function(data) {
                  if(data.code  == 0) {
                      $('.userTable  .table-tr-'+id).fadeOut( "slow", function() {
                        $('.userTable .table-tr-'+id).remove();
                      });
                  }
            }
            });
      }
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>