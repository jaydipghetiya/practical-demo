 $("document").ready(function() {

  //update user
   $('.updteuser').on('submit', function (e) {
          e.preventDefault();
          $('.errormsg').text('');  
          $.ajax({
            type: 'post',
            url: "/user/update-user",
            data: $('form').serialize(),
            error:function(data){
               console.log(data);
                $('.help-block').text('');
                var error = JSON.parse(data.responseText);
                $.each( error.errors, function( key, value ) {
                $('.'+key).text(value[0]); //showing only the first error.
              });
            },
            success: function (data) {
                 $('.succesmsg').text('User register successfully');
                 setTimeout(function(){ window.location.reload(); }, 3000);

            }
          });
    });
});